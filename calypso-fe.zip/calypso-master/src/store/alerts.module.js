export const alertsModule = {
    namespaced: true,
    state: {
        type: '',
        message: '',

    },
    getters: {
        alertType: state => state.type,
        alertMessage: state => state.message,
    },
    mutations: {
        setAlertType (state, payload) {
            state.type = payload.type
            state.message = payload.message
        },
        clearAlert (state) {
            state.type = ''
            state.message = ''
        },

    },

    actions: {
        turnOnAlert({commit}, data) {
            commit('setAlertType', data)

        },
        turnOffAlert({commit}) {
            commit('clearAlert')

        }

    }

}