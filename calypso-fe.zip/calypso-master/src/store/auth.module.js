import Vue from "vue";

export const authModule = {
  namespaced: true,
  state: {
    status: "",
    token: localStorage.getItem("token") || "",
    user: localStorage.getItem("user_id") || false,
    isGoogleAuthorized: localStorage.getItem("is_google_authorized") || false,
  },
  getters: {
    isLoggedIn: (state) => !!state.token,
    authStatus: (state) => state.status,
    isGoogleAuthorized: (state) => state.isGoogleAuthorized,
    userId: (state) => state.user,
  },
  mutations: {
    auth_request(state) {
      state.status = "loading";
    },

    auth_success(state, token) {
      state.status = "success";
      state.token = token;
    },

    set_user(state, user) {
      state.user = user._id;
    },

    auth_error(state) {
      state.status = "error";
    },

    logout(state) {
      state.status = "";
      state.token = "";
    },
  },

  actions: {
    login({ commit }, user) {
      return new Promise((resolve, reject) => {
        commit("auth_request");
        Vue.prototype.$http
          .post("/login", user)
          .then((resp) => {
            const token = resp.data.token;
            const user = resp.data.user;
            localStorage.setItem("token", token);
            commit("set_user", user._id);

            if (user.google_tokens && user.google_tokens[0]) {
              localStorage.setItem("is_google_authorized", true);
            } else {
              localStorage.removeItem("is_google_authorized");
            }

            localStorage.setItem("user_id", user._id);

            Vue.prototype.$http.defaults.headers.common[
              "Authorization"
            ] = token;
            commit("auth_success", token, user);
            resolve(resp);
          })
          .catch((err) => {
            commit("auth_error");
            localStorage.removeItem("token");
            reject(err);
          });
      });
    },
    fbLogin({ commit }, payload) {
      return new Promise((resolve, reject) => {
        commit("auth_request");
        Vue.prototype.$http
          .post("/facebook-login", payload)
          .then((resp) => {
            console.log("FROM auth.module.js ->>>> ", resp);
            const token = resp.data.token;
            const user = resp.data.user;
            console.log(resp.headers, token);
            localStorage.setItem("token", token);
            localStorage.setItem("image", user.image);
            Vue.prototype.$http.defaults.headers.common[
              "Authorization"
            ] = token;
            commit("auth_success", token, user);
            resolve(resp);
          })
          .catch((err) => {
            commit("auth_error");
            localStorage.removeItem("token");
            reject(err);
          });
      });
    },

    signup({ commit }, user) {
      return new Promise((resolve, reject) => {
        commit("auth_request");
        Vue.prototype.$http
          .post("register", user)
          .then((resp) => {
            const token = resp.data.token;
            const user = resp.data.user;
            localStorage.setItem("token", token);
            Vue.prototype.$http.defaults.headers.common[
              "Authorization"
            ] = token;
            commit("auth_success", token, user);
            resolve(resp);
          })
          .catch((err) => {
            commit("auth_error", err);
            localStorage.removeItem("token");
            reject(err);
          });
      });
    },

    logout({ commit }) {
      return new Promise((resolve) => {
        commit("logout");
        localStorage.removeItem("token");
        delete Vue.prototype.$http.defaults.headers.common["Authorization"];
        resolve();
      });
    },
  },
};
