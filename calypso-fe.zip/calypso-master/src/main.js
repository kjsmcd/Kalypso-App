import Vue from "vue";
import App from "./App.vue";
import vuetify from "./plugins/vuetify";
import router from "./router";
import store from "./store";
import Axios from "axios";
import { apiUrl } from "@/config";
import GSignInButton from "vue-google-signin-button";
import Directives from "./directives";
import * as VeeValidate from "vee-validate";

Vue.use(VeeValidate);

Object.keys(Directives).forEach((name) =>
  Vue.directive(name, Directives[name])
);

Vue.use(GSignInButton);

const FBGraphHttp = Axios.create({
  baseURL: "https://graph.facebook.com/v7.0/",
});

Vue.prototype.$http = Axios;
Vue.prototype.$http.defaults.baseURL = apiUrl;
Vue.prototype.$fbGraphAuth = FBGraphHttp;
const token = localStorage.getItem("token");

if (token) {
  Vue.prototype.$http.defaults.headers.common["Authorization"] = token;
}

Vue.config.productionTip = false;

window.appVue = new Vue({
  vuetify,
  router,
  store,
  $_veeValidate: {
    validator: "new",
  },
  render: (h) => h(App),
}).$mount("#app");
