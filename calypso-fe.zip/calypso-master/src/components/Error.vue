<template>
  <v-card width="400" class="mx-auto">
    <h3>Something wend wrong. Please contact support!</h3>
  </v-card>
</template>

<script>
export default {
  name: "Error",

  methods: {},
};
</script>

<style lang="scss" >
</style>