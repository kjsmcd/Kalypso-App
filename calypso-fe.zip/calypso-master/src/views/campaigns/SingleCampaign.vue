<template>
  <v-col cols="6" md="3">
    <div @click="$router.push(`/dashboard/${campaign._id}`)">
      <!--:to="`/details-campaign/${campaign._id}`"-->

      <v-card width="196px" height=" 228px" outlined>
        <div class="single-campaign">
          <div class="poster">
            <img :src="campaign.brand_logo ? campaign.brand_logo : logo" alt />
          </div>
          <v-divider></v-divider>
          <div class="campaign-info">
            <span class="budget">Budget: ${{ campaign.amount }}</span>
            <v-spacer></v-spacer>
            <div class="type">
              <img class="insta-story" src="@/assets/images/instagram-story.png" alt />
              <img class="insta-post" src="@/assets/images/instagram-post.png" alt />
              <span class="number-of-post">X{{ campaign.number_of_post}}</span>
            </div>
          </div>
          <h2>{{campaign.name}}</h2>
          <div
            class="due-date"
          >DUE: {{ new Date(campaign.due_date).toLocaleString().slice(0,10).replace(',', '') }}</div>
        </div>
      </v-card>
    </div>
  </v-col>
</template>

<script>
import Logo from "@/assets/images/logo.svg";

export default {
  name: "SingleCampaign",
  components: {},
  props: {
    campaign: {
      type: Object,
      required: true,
    },
  },
  data: () => ({ logo: Logo }),
};
</script>
<style lang="scss">
.single-campaign {
  .poster {
    height: 100px;
    padding: 7px 18px;
    & img {
      width: 100%;
      height: 100%;
    }
  }
  & hr {
    margin: 0 4px;
  }
  .campaign-info {
    align-items: center;
    padding: 12px 16px;
    display: flex;
    & .budget {
      color: #9165f7;
      font-family: "Open Sans", sans-serif;
      font-style: normal;
      font-weight: normal;
      font-size: 12px;
      line-height: 16px;
    }
    .type {
      align-items: center;
      display: flex;

      & .insta-story {
        margin-right: 9px;
      }
      & span {
        color: #30364d;
        font-family: "Open Sans", sans-serif;
        font-style: normal;
        font-weight: normal;
        font-size: 12px;
        line-height: 16px;
        margin-left: 5px;
      }
    }
  }
  & h2 {
    font-family: "Open Sans", sans-serif;
    font-style: normal;
    font-weight: 600;
    font-size: 14px;
    line-height: 20px;
    color: #30364d;
    padding: 0px 16px 4px 16px;
  }
  .due-date {
    font-family: "Open Sans", sans-serif;
    font-style: normal;
    font-weight: 600;
    font-size: 12px;
    line-height: 16px;
    color: #7982a3;
    padding: 0 16px;
  }
}
a {
  text-decoration: none;
}
</style>