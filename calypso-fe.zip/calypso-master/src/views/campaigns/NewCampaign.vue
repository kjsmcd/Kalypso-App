<template>
  <div>
    <h3 class="page-name">Campaigns</h3>
    <div class="inline">
      <img src="@/assets/images/home.svg" alt />
      <v-icon color="#BCC0CC">mdi-chevron-right</v-icon>
      <v-breadcrumbs :items="items">
        <template v-slot:item="{ item }">
          <v-breadcrumbs-item :href="item.href" class="active-link" :disabled="item.disabled">
            <v-icon v-if="item.icon">{{ item.icon }}</v-icon>
            {{ item.text }}
          </v-breadcrumbs-item>
        </template>
        <template v-slot:divider>
          <v-icon color="#BCC0CC">mdi-chevron-right</v-icon>
        </template>
      </v-breadcrumbs>
    </div>
    <v-container>
      <v-stepper class="stepper-padding" v-model="e1">
        <v-stepper-header>
          <v-stepper-step color="#9165F7" :complete="e1 > 1" step="1">Campaign Details</v-stepper-step>

          <v-divider></v-divider>

          <v-stepper-step color="#9165F7" :complete="e1 > 2" step="2">Campaign Content</v-stepper-step>

          <!-- <v-divider></v-divider> -->

          <!-- <v-stepper-step color="#9165F7" step="3">Documentation</v-stepper-step> -->
        </v-stepper-header>

        <v-stepper-items>
          <v-stepper-content step="1">
            <v-card class="mb-12" color="white" height="350px">
              <div class="card-name">Main Info</div>
              <v-divider class="divider-color"></v-divider>
              <v-form ref="form1">
                <v-row class="px-6 pt-8">
                  <v-col cols="12" sm="6" class="py-0">
                    <v-text-field
                      v-model="campaignName"
                      label="Campaign name (ex: Deoderant Launch)"
                      :rules="[(v) => !!v || 'Campaign Name is required']"
                      filled
                      class="input-style"
                      background="#F8F8FF"
                    ></v-text-field>
                  </v-col>
                  <v-col cols="12" sm="6" class="py-0">
                    <v-text-field
                      v-model="brandName"
                      :rules="[(v) => !!v || 'Brand name is required']"
                      label="Brand name (ex: Kopari)"
                      filled
                      class="input-style"
                      background="#F8F8FF"
                    ></v-text-field>
                  </v-col>
                  <v-col cols="12" sm="6" class="picker">
                    <v-menu
                      ref="menu"
                      v-model="menu"
                      :close-on-content-click="false"
                      transition="scale-transition"
                      offset-y
                      max-width="290px"
                      min-width="290px"
                    >
                      <template v-slot:activator="{ on }">
                        <v-text-field
                          v-model="dateFormatted"
                          label="Due Date"
                          class="input-style"
                          append-icon="mdi-calendar-blank-outline"
                          @blur="date = parseDate(dateFormatted)"
                          v-on="on"
                        ></v-text-field>
                      </template>
                      <v-date-picker v-model="date" no-title>
                        <v-spacer></v-spacer>
                        <v-btn width="auto" text color="primary" @click="menu = false">Cancel</v-btn>
                        <v-btn
                          width="auto"
                          text
                          color="primary"
                          @click="$refs.menu.save(dateFormatted)"
                        >OK</v-btn>
                      </v-date-picker>
                    </v-menu>
                    <!--<v-menu-->
                    <!--ref="menu"-->
                    <!--v-model="menu"-->
                    <!--:close-on-content-click="false"-->
                    <!--:return-value.sync="date"-->
                    <!--transition="scale-transition"-->
                    <!--offset-y-->
                    <!--min-width="290px"-->
                    <!--class="date-picker"-->
                    <!--&gt;-->
                    <!--<template v-slot:activator="{ on }">-->
                    <!--<v-text-field-->
                    <!--v-model="dateFormatted"-->
                    <!--label="Due Date"-->
                    <!--class="input-style"-->
                    <!--@blur="date = parseDate(dateFormatted)"-->
                    <!--append-icon="mdi-calendar-blank-outline"-->
                    <!--readonly-->
                    <!--v-on="on"-->
                    <!--&gt;</v-text-field>-->
                    <!--</template>-->
                    <!--<v-date-picker scrollable v-model="date" no-title>-->
                    <!--<v-spacer></v-spacer>-->
                    <!--<v-btn width="auto"  text color="primary" @click="menu = false">Cancel</v-btn>-->
                    <!--<v-btn width="auto"  text color="primary" @click="$refs.menu.save(dateFormatted)">OK</v-btn>-->
                    <!--</v-date-picker>-->
                    <!--</v-menu>-->
                  </v-col>
                  <v-col cols="12" sm="6" class="py-0">
                    <v-text-field
                      v-model="amount"
                      label="Budget"
                      :rules="[(v) => !!v || 'Budget is required']"
                      filled
                      class="input-style amount-input"
                      background="#F8F8FF"
                    ></v-text-field>
                  </v-col>
                </v-row>
              </v-form>

              <div class="pull-right">
                <v-btn @click="$router.push('/campaigns')" text>Cancel</v-btn>
                <v-btn color="primary" @click="validateStep1">Confirm</v-btn>
              </div>
            </v-card>
          </v-stepper-content>

          <v-stepper-content step="2">
            <div class="mb-12" color="white" height="350px">
              <v-row>
                <v-col cols="12" md="4" xs="12">
                  <div class="modal-mask">
                    <v-dialog v-model="dialog" scrollable max-width="448px">
                      <template v-slot:activator="{}">
                        <v-btn @click="openInstagramPostsDialog" class="modal-btn">
                          <img src="@/assets/images/instagram.png" alt />
                          Add Instagram
                          <br />Post
                        </v-btn>
                      </template>
                      <v-card class="modal-padding">
                        <div class="modal-header">
                          <div class="title-part">
                            <h1>Select Instagram Post</h1>
                            <p>
                              Select one or more posts you delivered
                              <br />for this campaign.
                            </p>
                          </div>
                          <v-spacer></v-spacer>
                          <div class="add-btn" @click="dialog=false" style="cursor:pointer">
                            <v-icon color=" white">mdi-plus</v-icon>
                            <span>
                              {{ selectedPosts.length }}
                              {{ selectedPosts > 0 ? "Selected" : "Add" }}
                            </span>
                          </div>
                        </div>
                        <v-divider></v-divider>
                        <v-card-text style="height: 592px;">
                          <v-row>
                            <v-col
                              v-for="(post, i) in posts"
                              @click="togglePost(i)"
                              :key="i"
                              class="d-flex child-flex"
                              cols="4"
                            >
                              <v-card
                                flat
                                tile
                                class="d-flex"
                                :class="post.is_selected ? 'selected-post' : ''"
                              >
                                <v-img :src="post.media_url" aspect-ratio="1">
                                  <template v-slot:placeholder>
                                    <v-row class="fill-height ma-0" align="center" justify="center">
                                      <v-progress-circular indeterminate color="grey lighten-5"></v-progress-circular>
                                    </v-row>
                                  </template>
                                </v-img>
                              </v-card>
                            </v-col>
                          </v-row>
                        </v-card-text>
                      </v-card>
                    </v-dialog>
                  </div>
                </v-col>
                <v-col cols="12" md="4" xs="12">
                  <div class="modal-mask">
                    <v-dialog v-model="dialog2" scrollable max-width="448px">
                      <template v-slot:activator="{  }">
                        <v-btn @click="openInstagramStoriesDialog" class="modal-btn">
                          <img src="@/assets/images/instagram.png" alt />
                          Add Instagram
                          <br />Story
                        </v-btn>
                      </template>
                      <v-card class="modal-padding">
                        <div class="modal-header">
                          <div class="title-part">
                            <h1>Select Instagram Story</h1>
                            <p>
                              Select one or more stories that you want to
                              <br />add to your campaign
                            </p>
                          </div>
                          <v-spacer></v-spacer>
                          <div @click="dialog2=false" style="cursor:pointer" class="add-btn">
                            <v-icon color=" white">mdi-plus</v-icon>
                            <span>
                              {{ selectedStories.length }}
                              {{
                              selectedStories.length > 0 ? "Selected" : "Add"
                              }}
                            </span>
                          </div>
                        </div>
                        <v-divider></v-divider>
                        <v-card-text style="height: 592px;">
                          <v-row>
                            <v-col
                              v-for="(story, i) in stories"
                              @click="toggleStory(i)"
                              :key="i"
                              class="d-flex child-flex"
                              cols="4"
                            >
                              <v-card
                                flat
                                tile
                                class="d-flex"
                                :class="
                                  story.is_selected ? 'selected-post' : ''
                                "
                              >
                                <v-img :src="story.media_url" aspect-ratio="1">
                                  <template v-slot:placeholder>
                                    <v-row class="fill-height ma-0" align="center" justify="center">
                                      <v-progress-circular indeterminate color="grey lighten-5"></v-progress-circular>
                                    </v-row>
                                  </template>
                                </v-img>
                              </v-card>
                            </v-col>
                          </v-row>
                        </v-card-text>
                      </v-card>
                    </v-dialog>
                  </div>
                </v-col>
                <v-col cols="12" md="4" xs="12">
                  <div class="modal-mask">
                    <v-dialog v-model="dialog3" scrollable max-width="448px">
                      <template v-slot:activator="{}">
                        <v-btn @click="openYoutubeDialog" class="modal-btn">
                          <img src="@/assets/images/youtube.svg" alt />
                          Add YouTube
                          <br />Video
                        </v-btn>
                      </template>
                      <v-card class="modal-padding">
                        <div class="modal-header">
                          <div class="title-part">
                            <h1>Select YouTube Video</h1>
                            <p>
                              Select one or more videos that you want to
                              <br />add to your campaign
                            </p>
                          </div>
                          <v-spacer></v-spacer>
                          <div class="add-btn" @click="dialog3=false" style="cursor:pointer">
                            <v-icon color=" white">mdi-plus</v-icon>
                            <span>
                              {{ selectedYtVideos.length }}
                              {{
                              selectedYtVideos.length > 0 ? "Selected" : "Add"
                              }}
                            </span>
                          </div>
                        </div>
                        <v-divider></v-divider>
                        <v-select
                          :items="ytChannels"
                          label="Choose YouTube Channel"
                          dense
                          @change="getYoutubeVideos"
                          rounded
                          v-model="selectedYtChannel"
                          item-value="contentDetails.relatedPlaylists.uploads"
                          item-text="snippet.title"
                          append-icon="mdi-chevron-down"
                          outlined
                        ></v-select>
                        <v-select
                          v-if="false"
                          :items="ytPlaylists"
                          label="Choose YouTube Playlist"
                          :disabled="playlistsLoading"
                          :loading="playlistsLoading"
                          dense
                          @change="getYoutubeVideos"
                          rounded
                          v-model="selectedYtPlaylist"
                          item-value="id"
                          item-text="snippet.title"
                          append-icon="mdi-chevron-down"
                          outlined
                        ></v-select>
                        <v-card-text v-loading="ytVideosLoading" style="height: 592px;">
                          <v-row>
                            <v-col
                              v-for="(video, i) in ytVideos"
                              @click="toggleVideo(i)"
                              :key="i"
                              class
                              cols="6"
                            >
                              <v-card
                                flat
                                tile
                                class="videos"
                                :class="
                                  video.is_selected ? 'selected-post' : ''
                                "
                              >
                                <img
                                  v-if="
                                    video.snippet &&
                                      video.snippet.thumbnails &&
                                      video.snippet.thumbnails.default
                                  "
                                  :src="video.snippet.thumbnails.default.url"
                                />
                              </v-card>
                              <div
                                :class="
                                  video.is_selected ? 'selected-video' : ''
                                "
                                class="video-title"
                              >{{ video.snippet.title }}</div>
                            </v-col>
                          </v-row>
                        </v-card-text>
                      </v-card>
                    </v-dialog>
                  </div>
                </v-col>
                <v-col cols="12" md="4" xs="12">
                  <div class="modal-mask">
                    <v-dialog v-model="dialog4" scrollable max-width="448px">
                      <template v-slot:activator="{ on }">
                        <v-btn class="modal-btn" v-on="on">
                          <img src="@/assets/images/pinterest.svg" alt />
                          <p>
                            Select one
                            <br />or more pins
                          </p>
                        </v-btn>
                      </template>
                      <v-card class="modal-padding">
                        <div class="modal-header">
                          <div class="title-part">
                            <h1>Select Pinterest</h1>
                            <p>
                              Select one or more pinterest that you want to
                              <br />add to your campaign
                            </p>
                          </div>
                          <v-spacer></v-spacer>
                          <div class="add-btn" @click="dialog2=false" style="cursor:pointer">
                            <v-icon color=" white">mdi-plus</v-icon>
                            <span>
                              {{ selectedBlogPosts.length }}
                              {{
                              selectedBlogPosts.length > 0
                              ? "Selected"
                              : "Add"
                              }}
                            </span>
                          </div>
                        </div>
                        <v-divider></v-divider>
                        <v-card-text style="height: 592px;">
                          <v-row>
                            <v-col class cols="6"></v-col>
                          </v-row>
                        </v-card-text>
                      </v-card>
                    </v-dialog>
                  </div>
                </v-col>
                <v-col cols="12" md="4" xs="12">
                  <div class="modal-mask">
                    <v-dialog v-model="dialog5" scrollable max-width="448px">
                      <template v-slot:activator="{  }">
                        <v-btn @click="openBlogsDialog" class="modal-btn">
                          <img src="@/assets/images/google.svg" alt />
                          <p>
                            Select one or
                            <br />more blog posts
                          </p>
                        </v-btn>
                      </template>
                      <v-card class="modal-padding">
                        <div class="modal-header">
                          <div class="title-part">
                            <h1>Select one or more blog posts</h1>
                            <p>
                              Select one or more google analytics that you want
                              to
                              <br />add to your campaign
                            </p>
                          </div>
                          <v-spacer></v-spacer>
                          <div class="add-btn" @click="dialog2=false" style="cursor:pointer">
                            <v-icon color=" white">mdi-plus</v-icon>
                            <span>
                              {{ selectedBlogPosts.length }}
                              {{
                              selectedBlogPosts.length > 0
                              ? "Selected"
                              : "Add"
                              }}
                            </span>
                          </div>
                        </div>
                        <v-divider></v-divider>
                        <v-select
                          :items="googleViews"
                          label="Choose Google View"
                          dense
                          @change="getStatistics"
                          rounded
                          v-model="selectedGoogleView"
                          item-value="id"
                          item-text="websiteUrl"
                          append-icon="mdi-chevron-down"
                          outlined
                        ></v-select>
                        <v-card-text style="height: 592px;">
                          <v-row v-if="blogPages.data">
                            <v-col
                              v-for="(post, i) in packedPages"
                              @click="toggleBlogPost(i)"
                              :key="i"
                              class
                              cols="6"
                            >
                              <v-card
                                flat
                                tile
                                class="d-flex"
                                :class="post.is_selected ? 'selected-post' : ''"
                              >
                                <span>{{ post["ga:pageTitle"] }}</span>
                              </v-card>
                            </v-col>
                            <v-col class cols="6">
                              <h3>Please choose your website</h3>
                            </v-col>
                          </v-row>
                        </v-card-text>
                      </v-card>
                    </v-dialog>
                  </div>
                </v-col>
              </v-row>
            </div>
            <div class="pull-right">
              <v-btn @click="e1 = 1" text>
                <v-icon>mdi-arrow-left</v-icon>Back
              </v-btn>
              <v-btn color="primary" @click="createCampaign">Confirm</v-btn>
            </div>
          </v-stepper-content>

          <!-- <v-stepper-content step="3"> -->
          <!-- <div>
            <vue-dropzone
              @vdropzone-success="fileUploaded"
              ref="myVueDropzone"
              id="dropzone"
              :options="dropzoneOptions"
            ></vue-dropzone>
          </div>
          <div class="pull-right">
            <v-btn @click="e1 = 2" text>
              <v-icon>mdi-arrow-left</v-icon>Back
            </v-btn>
            <v-btn color="primary" @click="createCampaign">Confirm</v-btn>
          </div>-->
          <!-- </v-stepper-content> -->
        </v-stepper-items>
      </v-stepper>
      <v-row>
        <v-col cols="12" md="4" xs="12">
          <div class="modal-mask">
            <v-dialog style="overflow:visible" v-model="warning" scrollable max-width="500px">
              <template v-slot:activator="{ on, attrs }">
                <v-btn color="primary" dark v-bind="attrs" v-on="on">Open Dialog</v-btn>
              </template>
              <v-card class="modal-padding">
                <div class="modal-header">
                  Warning
                  <v-spacer></v-spacer>
                  <v-icon @click="warning = false" class="float-right">mdi-close</v-icon>
                </div>
                <v-divider></v-divider>

                <v-card-text style="margin-top:20px">{{ this.warningMessage }}</v-card-text>
                <v-row>
                  <v-col sm="12">
                    <v-btn
                      class="float-right ml2"
                      color="green darken-1"
                      text
                      @click="$router.push('/accounts')"
                    >Connect Now</v-btn>
                    <v-btn
                      class="float-right ml2"
                      color="green darken-1"
                      text
                      @click="warning = false"
                    >Cancel</v-btn>
                  </v-col>
                </v-row>
              </v-card>
            </v-dialog>
          </div>
        </v-col>
      </v-row>
    </v-container>
  </div>
</template>

<script>
// import vue2Dropzone from "vue2-dropzone";
import "vue2-dropzone/dist/vue2Dropzone.min.css";

const getTemplate = () => `
<div class="dz-preview dz-file-preview">
  <div class="dz-image">
    <div data-dz-thumbnail-bg></div>
  </div>
  <div class="dz-details">
    <div class="dz-size"><span data-dz-size></span></div>
    <div class="dz-filename"><span data-dz-name></span></div>
  </div>
  <div class="dz-progress"><span class="dz-upload" data-dz-uploadprogress></span></div>
  <div class="dz-error-message"><span data-dz-errormessage></span></div>
  <div class="dz-success-mark"><i class="fa fa-check"></i></div>
  <div class="dz-error-mark"><i class="fa fa-close"></i></div>
</div>
`;
import { FbAppId } from "../../config";

export default {
  name: "NewCampaign",
  components: {
    // vueDropzone: vue2Dropzone
  },
  data: (vm) => ({
    warning: false,
    warningMessage: false,
    ytChannels: [],
    ytVideos: [],
    ytPlaylists: [],
    selectedYtPlaylist: null,
    playlistsLoading: null,
    selectedYtChannel: null,
    ytVideosLoading: false,
    dropzoneOptions: {
      url: `${vm.$http.defaults.baseURL}campaigns/upload`,
      maxFilesize: 4, // MB
      maxFiles: 1,
      thumbnailWidth: 150, // px
      thumbnailHeight: 150,
      dictDefaultMessage:
        "<img src='@/assets/images/file.svg'><div class='dropzone-title'><strong>Choose a file</strong> or <br> drag it here</div>",
      includeStyling: false,
      addRemoveLinks: true,
      headers: {
        Authorization: vm.$http.defaults.headers.common["Authorization"],
      },
    },
    e1: 1,
    date: new Date().toISOString().substr(0, 10),
    dateFormatted: vm.formatDate(new Date().toISOString().substr(0, 10)),
    menu: false,
    modal: false,
    menu2: false,
    first: "",
    dialog: false,
    dialog2: false,
    dialog3: false,
    dialog4: false,
    dialog5: false,
    amount: "",
    campaignName: "",
    brandName: "",
    images: [],
    posts: [],
    stories: [],
    brand_logo: null,
    googleViews: [],
    blogPages: [],
    packedPages: [],
    selectedGoogleView: null,
    user: {},
    items: [
      {
        text: "Campaigns",
      },
      {
        text: "New Campaign",
      },
    ],
  }),
  async created() {
    this.getUser().then(this.getYtChannels);
  },
  methods: {
    getCampaignImage() {
      if (
        this.selectedYtVideos.length &&
        this.selectedYtVideos[0] &&
        this.selectedYtVideos[0].snippet
      ) {
        let snippet = this.selectedYtVideos[0].snippet;
        let image = snippet.thumbnails.default.url;
        return image;
      } else if (this.selectedPosts.length) {
        return this.selectedPosts[0].media_url;
      } else {
        return null;
      }
    },
    async getUser() {
      try {
        let response = await this.$http.get(`get-user`);
        this.user = response.data;
      } catch (error) {
        console.log(error);
      }
    },
    openInstagramPostsDialog() {
      if (!this.user.fb_access_token) {
        this.warning = "true";
        this.warningMessage =
          "Please complete your Instagram Authorization on Social Accounts page.";
        return;
      }
      this.dialog = true;
      this.initAndFetchInstagramStuff();
    },
    openBlogsDialog() {
      if (
        !(
          this.user.google_tokens &&
          this.user.google_tokens[0] &&
          this.user.google_tokens[0].access_token
        )
      ) {
        this.warning = "true";
        this.warningMessage =
          "Please complete your Google Authorization on Social Accounts page";
        return;
      }
      this.getBlogs();

      this.dialog5 = true;
    },
    openInstagramStoriesDialog() {
      if (!this.user.fb_access_token) {
        this.warning = "true";
        this.warningMessage =
          "Please complete your Instagram Authorization on Social Accounts page.";
        return;
      }
      this.dialog2 = true;
      this.initAndFetchInstagramStuff();
    },
    openYoutubeDialog() {
      if (
        !(
          this.user.google_tokens &&
          this.user.google_tokens[0] &&
          this.user.google_tokens[0].access_token
        )
      ) {
        this.warning = "true";
        this.warningMessage =
          "Please complete your Google Authorization on Social Accounts page";
        return;
      }
      this.dialog3 = true;
      this.getYtChannels();
    },
    async getYoutubeVideos() {
      try {
        let ytVideosResponse = await this.$http.get(
          `/auth/get-ytvideos/${this.user._id}/${this.selectedYtChannel}`
        );
        if (ytVideosResponse.data.data && ytVideosResponse.data.data.items) {
          ytVideosResponse.data.data.items.forEach((item) => {
            item.is_selected = false;
          });
          this.ytVideos = ytVideosResponse.data.data.items;
        }
        console.log(ytVideosResponse.data);
      } catch (e) {
        console.error(e);
      }
    },
    async getYoutubePlaylists() {
      this.playlistsLoading = true;
      try {
        let playlistResponse = await this.$http.get(
          `/auth/get-ytchannels/${this.user._id}/${this.selectedYtChannel}`
        );
        this.ytPlaylists = playlistResponse.data.data.items;
      } catch (e) {
        console.error(e);
      } finally {
        this.playlistsLoading = false;
      }
    },
    async getYtChannels() {
      if (
        !(
          this.user.google_tokens &&
          this.user.google_tokens[0] &&
          this.user.google_tokens[0].access_token
        )
      ) {
        this.warning = "true";
        this.warningMessage =
          "Please complete your Google Authorization on Social Accounts page";
        return;
      }
      try {
        let response = await this.$http.get(
          `/auth/get-ytchannels/${this.user._id}`
        );
        if (response.data.data && response.data.data.items) {
          this.ytChannels = response.data.data.items;
        }
        console.log(response);
      } catch (e) {
        console.error(e);
      }
    },
    async getBlogs() {
      if (
        !(
          this.user.google_tokens &&
          this.user.google_tokens[0] &&
          this.user.google_tokens[0].access_token
        )
      ) {
        this.warning = "true";
        this.warningMessage =
          "Please complete your Google Authorization on Social Accounts page";
        return;
      }
      try {
        let response = await this.$http.get(`/auth/get-views/${this.user._id}`);
        this.googleViews = response.data.data.items;
        console.log(response);
      } catch (e) {
        console.error(e);
      }
    },
    async getStatistics() {
      try {
        let response = await this.$http.get(
          `auth/gareport/${this.userId}/${this.selectedGoogleView}`
        );
        if (response.data.data.rows) {
          response.data.data.rows.forEach((item, i) => {
            let newObject = {};

            Object.keys(item).forEach((key, index) => {
              if (response.data.data.columnHeaders[index]) {
                newObject[response.data.data.columnHeaders[index].name] =
                  item[index];
              }
            });
            newObject.is_selected = false;

            this.packedPages.push(newObject);
          });
        } else {
          alert("No results");
        }

        this.blogPages = response.data;
        console.log(response);
      } catch (e) {
        console.error(e);
      }
    },
    async initAndFetchInstagramStuff() {
      try {
        this.getInstagramPosts();
        this.getInstagramStories();
      } catch (e) {
        console.error(e);
      }
    },

    fileUploaded(file, response) {
      this.brand_logo = response.data.Location;
    },
    formatDate(date) {
      if (!date) return null;

      const [year, month, day] = date.split("-");
      return `${month}/${day}/${year}`;
    },
    parseDate(date) {
      if (!date) return null;

      const [month, day, year] = date.split("/");
      return `${year}-${month.padStart(2, "0")}-${day.padStart(2, "0")}`;
    },
    validateStep1() {
      console.log(this.$refs.form1);
      if (this.$refs.form1.validate()) {
        this.e1 = 2;
      }
    },
    async getInstagramPosts() {
      let response = await this.$http.get("/instagram/posts");
      response.data.forEach((item) => {
        item.is_selected = false;
      });
      this.posts = response.data;
      console.log(response);
    },
    async getInstagramStories() {
      let response = await this.$http.get("/instagram/stories");
      console.log(response.data);

      response.data.forEach((item) => {
        item.is_selected = false;
      });
      this.stories = response.data;
    },
    togglePost: function (i) {
      let value = this.posts[i].is_selected;
      if (typeof this.posts[i].is_selected === "undefined") {
        value = false;
      }
      console.log(value);

      this.posts[i].is_selected = !value;
    },
    toggleBlogPost: function (i) {
      let value = this.packedPages[i].is_selected;
      if (typeof this.packedPages[i].is_selected === "undefined") {
        value = false;
      }
      console.log(value);

      this.packedPages[i].is_selected = !value;
    },

    toggleVideo: function (i) {
      let value = this.ytVideos[i].is_selected;
      if (typeof this.ytVideos[i].is_selected === "undefined") {
        value = false;
      }

      this.ytVideos[i].is_selected = !value;
    },
    toggleStory: function (i) {
      let value = this.stories[i].is_selected;
      if (typeof this.stories[i].is_selected === "undefined") {
        value = false;
      }
      console.log(value);

      this.stories[i].is_selected = !value;
    },
    async createCampaign() {
      let data = {
        name: this.campaignName,
        brand_name: this.brandName,
        due_date: this.date,
        amount: this.amount.replace("$", ""),
        posts: this.selectedPosts,
        stories: this.selectedStories,
        yt_videos: this.selectedYtVideos,
        blog_pages: this.selectedBlogPosts,
        brand_logo: this.getCampaignImage(),
      };

      try {
        let response = await this.$http.post(`/campaigns`, data);
        this.$router.push("/dashboard/" + response.data._id);
      } catch (error) {
        console.log(error);
        this.$store.dispatch("alertsModule/turnOnAlert", {
          type: "error",
          message: error.message,
        });
      }
    },
  },
  computed: {
    isGoogleAuthorized: function () {
      return this.$store.getters["authModule/isGoogleAuthorized"];
    },
    userId: function () {
      return this.$store.getters["authModule/userId"];
    },
    selectedPosts: function () {
      let selectedPosts;

      selectedPosts = this.posts.filter((post) => {
        return post.is_selected;
      });

      return selectedPosts;
    },
    videos: {
      get() {
        console.log(this.$store);
        return this.$store.state.youtubeModule.videos;
      },

      set(value) {
        this.$store.commit("update_video", value);
      },
    },
    selectedStories: function () {
      let selectedStories;

      selectedStories = this.stories.filter((story) => {
        return story.is_selected;
      });

      console.log(selectedStories);

      return selectedStories;
    },
    selectedYtVideos: function () {
      let selectedVideos;

      selectedVideos = this.ytVideos.filter((video) => {
        return video.is_selected;
      });

      return selectedVideos;
    },
    selectedBlogPosts: function () {
      let selectedBlogPosts;

      selectedBlogPosts = this.packedPages.filter((post) => {
        return post.is_selected;
      });

      return selectedBlogPosts;
    },
  },
  watch: {
    date(val) {
      this.dateFormatted = this.formatDate(this.date);
    },
    amount: function (newValue) {
      newValue = newValue.replace(/[^\d]/g, "").trim();
      if (newValue.length > 0) {
        newValue = "$" + newValue;
      }
      this.amount = newValue;
    },
  },
};
</script>

<style lang="scss">
@import url("https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css");
.v-dialog {
  overflow: hidden;
}
.inline {
  display: flex;
  align-items: center;
  padding-left: 32px;
}

.page-name {
  padding: 36px 0 0 32px;
  font-family: "Fira Sans", sans-serif;
  font-style: normal;
  font-weight: normal;
  font-size: 24px;
  line-height: 32px;
  color: #30364d;
}

.active-link {
  color: #7982a3;
  font-family: "Open Sans", sans-serif;
  font-style: normal;
  font-weight: normal;
  font-size: 12px;
  line-height: 16px;
}

.v-breadcrumbs {
  padding: 8px 5px;
}
.v-breadcrumbs li:nth-child(even) {
  padding: 0 5px;
}
.inline i {
  font-size: 16px !important;
}

.inline img {
  padding-right: 5px;
}

.theme--light.v-stepper .v-stepper__step__step {
  font-family: " Fira Sans", sans-serif;
  font-style: normal;
  font-weight: normal;
  font-size: 18px;
  line-height: 24px;
}

.theme--light.v-stepper
  .v-stepper__step:not(.v-stepper__step--active):not(.v-stepper__step--complete):not(.v-stepper__step--error)
  .v-stepper__step__step {
  background: #ededff !important;
  color: black;
}

.stepper-padding {
  margin: 0 16%;
}

.v-stepper__header {
  box-shadow: none;
}

.theme--light.v-stepper {
  background: transparent;
}

.v-stepper {
  box-shadow: none;
}

.v-stepper__step__step.primary {
  background-color: red !important;
  border-color: red !important;
}

.v-stepper__step__step {
  width: 40px !important;
  height: 40px !important;
}

.theme--light.v-btn:not(.v-btn--flat):not(.v-btn--text):not(.v-btn--outlined) {
  background: linear-gradient(327.48deg, #6a4ee1 0%, #b87df9 100%) !important;
  color: white !important;
}

.v-btn:not(.v-btn--round).v-size--default {
  height: 40px !important;
  border-radius: 32px;
  background: #ededff;
  color: #9165f7;
  margin-right: 8px;
}

.v-divider.divider-color {
  border-color: #f8f8ff;
}

.card-name {
  padding: 18px 24px;
  font-family: "Open Sans", sans-serif;
  font-style: normal;
  font-weight: 600;
  font-size: 14px;
  line-height: 20px;
  color: #30364d;
}

.theme--light.v-stepper .v-stepper__step--active .v-stepper__label {
  font-family: "Open Sans", sans-serif;
  font-style: normal;
  font-weight: 600;
  font-size: 14px;
  line-height: 20px;
  color: #30364d;
}
.v-text-field__slot label {
  font-family: "Open Sans", sans-serif;
  font-style: normal;
  font-weight: normal;
  font-size: 14px;
  line-height: 20px;
}

.input-style {
  font-family: "Open Sans", sans-serif;
  font-style: normal;
  font-weight: normal;
  font-size: 14px;
  margin-top: 0;

  &:focus {
    outline: none;
  }
  & .v-input__slot {
    border-radius: 4px !important;
    box-shadow: inset 0px -1px 0px #7982a3;
    background: #f8f8ff !important;
    padding-left: 15px;

    &:before {
      border-color: transparent !important;
    }
    &:after {
      border-color: transparent !important;
    }
    & .primary--text {
      color: #bcc0cc !important;
    }
    & label {
      color: #7982a3;
    }
    & input {
      color: #30364d;
    }
  }
}

.v-text-field.v-text-field--enclosed:not(.v-text-field--rounded)
  > .v-input__control
  > .v-input__slot,
.v-text-field.v-text-field--enclosed .v-text-field__details {
  border-radius: 4px;
}

::-webkit-input-placeholder {
  /* Edge */
  color: #7982a3;
}

:-ms-input-placeholder {
  /* Internet Explorer 10-11 */
  color: #7982a3;
}

::placeholder {
  color: #7982a3;
}

.picker {
  & .v-input__slot {
    height: 56px;

    & .v-text-field__slot {
      top: 10px;
    }
    & .theme--light.v-icon {
      color: #7982a3;
    }
    .v-input__icon {
      margin: 13px 8px;
    }
  }

  & .v-input {
    margin-top: -24px;
  }
}

.date-picker {
  & .v-picker__title {
    display: none;
  }
}

.pull-right {
  padding-right: 18px;
  text-align: right;
}

.v-stepper__wrapper
  .modal-mask
  .modal-btn.v-btn:not(.v-btn--round).v-size--default {
  border: 1px solid #e6e8f0;
  box-sizing: border-box;
  border-radius: 4px !important;
  width: 195px;
  margin: auto;
  height: 195px !important;
  background: transparent !important;
  box-shadow: none;
  & span {
    color: #7982a3;
    font-family: "Open Sans", sans-serif;
    font-style: normal;
    font-weight: normal;
    font-size: 14px;
    line-height: 20px;
    text-transform: capitalize;
    display: inline-grid;
    justify-items: center;

    & img {
      margin-bottom: 16px;
    }
  }
}

.modal-header {
  display: flex;
  padding: 18px 24px;
  .title-part {
    font-family: "Open Sans", sans-serif;
    font-style: normal;
    color: #30364d;
    & h1 {
      font-weight: 600;
      font-size: 14px;
      line-height: 20px;
      margin-bottom: 4px;
    }
    & p {
      font-weight: normal;
      font-size: 12px;
      line-height: 16px;
      margin-bottom: 0;
    }
  }
  .add-btn {
    background: linear-gradient(327.48deg, #6a4ee1 0%, #b87df9 100%);
    border-radius: 32px;
    width: 103px;
    font-family: Open Sans;
    font-style: normal;
    font-weight: 600;
    font-size: 14px;
    line-height: 20px;
    color: white;
    height: 40px;
    justify-content: center;
    align-items: center;
    display: flex;
    & i {
      font-style: normal;
      font-weight: 300;
      font-size: 16px;
      line-height: 24px;
    }
  }
}

.selected-post {
  border: 1px solid #9165f7;
  box-sizing: border-box;
  border-radius: 4px;
  border-color: #9165f7 !important;
  padding: 8px;

  & .v-image {
    border-radius: 0 !important;
  }
}

.videos {
  &.selected-post {
    padding: 0;
  }
  & img {
    width: 100%;
    height: 100%;
  }
}

.selected-video {
  color: #9165f7 !important;
}

.video-title {
  color: #30364d;
  font-family: "Open Sans", sans-serif;
  font-style: normal;
  font-weight: normal;
  font-size: 12px;
  line-height: 16px;
}

.video-info {
  color: #7982a3;
  font-family: "Open Sans", sans-serif;
  font-style: normal;
  font-weight: normal;
  font-size: 12px;
  line-height: 16px;
}
@media only screen and (max-width: 768px) {
  .stepper-padding {
    margin: 0 !important;
  }
  .v-card {
    height: auto !important;
  }
  .pull-right {
    padding-bottom: 20px;
  }
  .modal-mask {
    text-align: center;
  }
}
.vue-dropzone {
  width: 196px;
  border: 1px dashed #e6e8f0;
  border-radius: 4px;
  margin: auto;
  height: 196px;
  background: transparent;
  margin-bottom: 32px;
  .dropzone-title {
    font-family: "Open Sans", sans-serif;
    font-style: normal;
    font-weight: normal;
    font-size: 14px;
    line-height: 20px;
    color: #7982a3;
    margin-top: 16px;

    & strong {
      color: #31364e;
    }
  }
}
</style>
