<template>

</template>

<script>
	export default {
		name: 'PostsDialog',
		data: () => {

		}
	}
</script>

<style lang="scss">

</style>