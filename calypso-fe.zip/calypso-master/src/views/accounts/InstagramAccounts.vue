<template>
  <v-container v-loading="isAuthorizing">
    <div class="mb-12" color="white" height="350px">
      <h2
        class="card-name pt-12 text-center"
      >To create a high-level overview of how your brand campaign performed, we need to connect all possible social platforms</h2>

      <div class="connect-holder">
        <div class="d-flex align-center">
        <a :href="`${this.facebookUrl}`" class="connect-account">
          <div class="d-flex align-center justify-center text-center" style="height: 100%;">
            <div>
              <img src="@/assets/images/instagram.svg" alt />
              <div>
                Connect Instagram
                Account
              </div>
            </div>
          </div>
          <p v-if="user.fb_access_token">You've already authorized Kalypso with Instagram.</p>
        </a>
        <v-col sm="4">
          <v-select
                  :items="businessAccounts"
                  label="Choose Your Business Account"
                  dense
                  rounded
                  v-model="selectedAccount"
                  @change="setInstagramAccount"
                  item-value="id"
                  item-text="name"
                  append-icon="mdi-chevron-down"
                  outlined
          ></v-select>
        </v-col>
        </div>

        <a class="connect-account">
          <div class="d-flex align-center justify-center text-center" style="height: 100%;">
            <div>
              <img width="55" src="@/assets/images/pinterest.png" alt />
              <div>
                Connect Pinterest
                Account - COMING SOON
              </div>
            </div>
          </div>
        </a>
        <a :disabled="isGoogleAuthorized" :href="googleAuthUrl" class="connect-account">
          <div class="d-flex align-center justify-center text-center" style="height: 100%;">
            <div>
              <img width="35" src="@/assets/images/analytics.png" alt />
              <div>
                Connect Google and Youtube
                Analytics
              </div>
            </div>
          </div>
          <p
            v-if="user.google_tokens && user.google_tokens[0] && user.google_tokens[0].access_token"
          >You've already authorized Kalypso with Google.</p>
        </a>
      </div>
    </div>



  </v-container>
</template>

<script>
export default {
  components: {},
  created() {
    this.fetchFacebookUrl();
    this.getBusinessAccounts();
    this.fetchGoogleUrl();
    this.getUser();
    this.$store.dispatch("youtubeModule/gapiAuthInit");
  },
  methods: {
    async setInstagramAccount() {
      try {
        let response = await this.$http.post(
          `instagram/set-account/${this.selectedAccount}`
        );
        console.log(response);
      } catch (error) {
        console.log(error);
        this.$store.dispatch("alertsModule/turnOnAlert", {
          type: "error",
          message: error.message,
        });
      }
    },
    async getBusinessAccounts() {
      try {
        let response = await this.$http.get(`instagram/accounts`);
        console.log(response);
        this.businessAccounts = response.data.data;
      } catch (error) {
        console.log(error);
        this.$store.dispatch("alertsModule/turnOnAlert", {
          type: "error",
          message: "Something went wrong!",
        });
      }
    },
    async getUser() {
      try {
        let response = await this.$http.get(`get-user`);
        this.user = response.data;
        this.selectedAccount = this.user.chosen_instagram_account;
      } catch (error) {
        console.log(error);
        this.$store.dispatch("alertsModule/turnOnAlert", {
          type: "error",
          message: "Something went wrong!",
        });
      }
    },
    async fetchFacebookUrl() {
      try {
        let response = await this.$http.get(`get-facebook-url`);
        this.facebookUrl = response.data;
      } catch (error) {
        console.log(error);
        this.$store.dispatch("alertsModule/turnOnAlert", {
          type: "error",
          message: "Something went wrong!",
        });
      }
    },
    async fetchGoogleUrl() {
      try {
        let response = await this.$http.get(`get-google-url`);
        this.googleAuthUrl = response.data;
      } catch (error) {
        console.log(error);
        this.$store.dispatch("alertsModule/turnOnAlert", {
          type: "error",
          message: "Something went wrong!",
        });
      }
    },

    authenticate() {
      return this.$store.dispatch("youtubeModule/gapiAuthenticate");
    },
    loadClient() {
      return this.$store.dispatch("youtubeModule/gapiLoadClient");
    },
    // Make sure the client is loaded and sign-in is complete before calling this method.
    execute() {
      return this.$store.dispatch("youtubeModule/gapiExecute");
    },

    getUploadedVideos() {
      return this.$store.dispatch("youtubeModule/getUploadedVideos");
    },
  },

  data: () => ({
    accounts: [],
    user: {},
    selectedAccount: null,
    businessAccounts: [],
    facebookUrl: "",
    googleAuthUrl: "",
  }),

  computed: {
    isAuthorizing() {
      return this.$store.getters["youtubeModule/isAuthorizing"];
    },

    isGoogleAuthorized: function () {
      return this.$store.getters["authModule/isGoogleAuthorized"];
    },
    userId: function () {
      return this.$store.getters["authModule/userId"];
    },
  },
};
</script>
<style lang="scss" scoped>
.connect-holder {
  display: block;
  justify-content: center;
  align-items: center;
  padding: 0 20px;
  padding-top: 60px;

  & .connect-account {
    border: 1px solid #e6e8f0;
    border-radius: 4px;
    margin: 20px 8px;
    width: 196px;
    display: block;
    height: 196px;
    color: #7982a3;
    padding: 0 20px;
    & img,
    .v-image {
      margin-bottom: 16px;
    }
  }
}
</style>
