let baseUrl = "";
let FB_APP_ID = "";
let STRIPE_PUBLIC_KEY = "";

if (process.env.NODE_ENV === "production") {
  baseUrl = "https://d2871qaba6qfgd.cloudfront.net/";
  FB_APP_ID = "264514927939052";
  STRIPE_PUBLIC_KEY = "pk_test_FKwJ4XAMLBwpIgfTAldY8hAS001hWH9dIS";
} else {
  baseUrl = "http://localhost:3000/";
  FB_APP_ID = "264514927939052";
  STRIPE_PUBLIC_KEY = "pk_test_FKwJ4XAMLBwpIgfTAldY8hAS001hWH9dIS";
}

export const apiUrl = baseUrl;
export const FbAppId = FB_APP_ID;
export const stripePk = STRIPE_PUBLIC_KEY;
