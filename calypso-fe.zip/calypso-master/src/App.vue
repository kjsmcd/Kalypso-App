<template>
  <v-app>
    <navigation v-if="isLoggedIn" />
    <v-content class="main-bg-color">
      <alerts />
      <horizontal-navigation v-if="isLoggedIn" />
      <transition name="fade" mode="out-in">
        <router-view />
      </transition>
    </v-content>
  </v-app>
</template>

<script>
import Navigation from "@/components/Navigation";
import HorizontalNavigation from "@/components/HorizontalNavigation";
import Alerts from "@/components/Alerts";
import "./assets/css/main.css";
import { FbAppId } from "../src/config";

export default {
  components: {
    HorizontalNavigation,
    Navigation,
    Alerts,
  },

  computed: {
    isLoggedIn: function () {
      return this.$store.getters["authModule/isLoggedIn"];
    },
  },

  created: function () {
    this.loadFacebookSDK(document, "script", "facebook-jssdk");
    this.initFacebook();
    const vm = this;
    vm.$http.interceptors.response.use(
      (response) => {
        return response;
      },
      (err) => {
        let isAuthRoute =
          vm.$route.name === "Signup" ||
          vm.$route.name === "Login" ||
          vm.$route.name === "Forget" ||
          vm.$route.name === "Reset";
        console.log("is route", isAuthRoute);
        if (err.status && err.response) {
          if (!isAuthRoute) {
            const responseData = err.response.data;
            const responseStatus = err.response.status;
            console.log(err, responseStatus);
            return new Promise((resolve, reject) => {
              if (responseStatus === 401 && !isAuthRoute) {
                this.logout();
              } else {
                reject(err.response.data);
              }
            });
          } else {
            return new Promise((resolve, reject) => {
              reject(err.response.data);
            });
          }
        } else if (err.response && err.response.status) {
          if (!isAuthRoute && err.response.status == 401) {
            this.logout();
          }
          return new Promise((resolve, reject) => {
            reject({
              message: err.response.data.error,
            });
          });
        } else {
          return new Promise((resolve, reject) => {
            reject({
              message: "Something went wrong",
            });
          });
        }
      }
    );
  },

  methods: {
    async initFacebook() {
      window.fbAsyncInit = function () {
        window.FB.init({
          appId: FbAppId, //You will need to change this
          cookie: true, // This is important, it's not enabled by default
          version: "v13.0",
        });
      };
    },
    async loadFacebookSDK(d, s, id) {
      var js,
        fjs = d.getElementsByTagName(s)[0];
      if (d.getElementById(id)) {
        return;
      }
      js = d.createElement(s);
      js.id = id;
      js.src = "https://connect.facebook.net/en_US/sdk.js";
      fjs.parentNode.insertBefore(js, fjs);
    },
    logout: function () {
      this.$store
        .dispatch("authModule/logout")
        .then((ee) => {
          this.$router.push("/login");
        })
        .catch((error) => {
          console.warn(error);
        });
    },
  },
};
</script>
<style lang="scss">
.main-bg-color {
  background-color: #f8f8ff;
}

.fade-enter-active,
.fade-leave-active {
  transition-duration: 0.3s;
  transition-property: opacity;
  transition-timing-function: ease;
}

.fade-enter,
.fade-leave-active {
  opacity: 0;
}
</style>
