module.exports = {
  "transpileDependencies": [
    "vuetify"
  ],
    devServer: {
       https: true 
      }
}