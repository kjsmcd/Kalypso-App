// // import crypto from 'crypto-random-string'
//
// const { sendVerificationEmail } = require('../utils/email');
//
// const SignUpController = (req, res, next) => {
//
// };
//
